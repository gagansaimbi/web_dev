
  let sum = 0
    let c1_1 = document.getElementById("1.1")
    let c1_2 = document.getElementById("1.2")
    let c1_3 = document.getElementById("1.3")

    let c2_1 = document.getElementById("2.1")
    let c2_2 = document.getElementById("2.2")
    let c2_3 = document.getElementById("2.3")

    let c3_1 = document.getElementById("3.1")
    let c3_2 = document.getElementById("3.2")
    let c3_3 = document.getElementById("3.3")

    
function o(tbl) {
    
    if(sum%2==0){
        tbl.innerHTML="O"
    }
    else{
        tbl.innerText="X"
    }
    
    sum+=1
    console.log(sum)
    
    announce()
        
}

function game(){
    
    
    document.getElementById("1.1").onclick=function() {o(c1_1)}
    document.getElementById("1.2").onclick=function() {o(c1_2)}
    document.getElementById("1.3").onclick=function() {o(c1_3)}

    document.getElementById("2.1").onclick=function() {o(c2_1)}
    document.getElementById("2.2").onclick=function() {o(c2_2)}
    document.getElementById("2.3").onclick=function() {o(c2_3)}

    document.getElementById("3.1").onclick=function() {o(c3_1)}
    document.getElementById("3.2").onclick=function() {o(c3_2)}
    document.getElementById("3.3").onclick=function() {o(c3_3)}  
}

function announce(){
    //player-1 check
    if(document.getElementById(1.1).innerText=='O'
        &&
        document.getElementById(1.2).innerText=='O'
        &&
        document.getElementById(1.3).innerText=='O'
        ){
        alert("Player-1 wins")
        
    }
    else if(document.getElementById(2.1).innerText=='O'
            &&
            document.getElementById(2.2).innerText=='O'
            &&
            document.getElementById(2.3).innerText=='O'
            ){
            alert("Player-1 wins")
    }
    else if(document.getElementById(3.1).innerText=='O'
            &&
            document.getElementById(3.2).innerText=='O'
            &&
            document.getElementById(3.3).innerText=='O'
            ){
            alert("Player-1 wins")
    }
    else if(document.getElementById(1.1).innerText=='O'
            &&
            document.getElementById(2.1).innerText=='O'
            &&
            document.getElementById(3.1).innerText=='O'
            ){
            alert("Player-1 wins")
    }
    else if(document.getElementById(1.2).innerText=='O'
            &&
            document.getElementById(2.2).innerText=='O'
            &&
            document.getElementById(3.2).innerText=='O'
            ){
            alert("Player-1 wins")
    }
    else if(document.getElementById(1.3).innerText=='O'
            &&
            document.getElementById(2.3).innerText=='O'
            &&
            document.getElementById(3.3).innerText=='O'
            ){
            alert("Player-1 wins")
    }
    else if(document.getElementById(1.1).innerText=='O'
            &&
            document.getElementById(2.2).innerText=='O'
            &&
            document.getElementById(3.3).innerText=='O'
            ){
            alert("Player-1 wins")
    }
    else if(document.getElementById(1.3).innerText=='O'
            &&
            document.getElementById(2.2).innerText=='O'
            &&
            document.getElementById(3.1).innerText=='O'
            ){
            alert("Player-1 wins")
    }

    //player-2 cehck starts

    else if(document.getElementById(1.1).innerText=='X'
            &&
            document.getElementById(1.2).innerText=='X'
            &&
            document.getElementById(1.3).innerText=='X'
            ){
            alert("Player-2 wins")
        
    }
    else if(document.getElementById(2.1).innerText=='X'
            &&
            document.getElementById(2.2).innerText=='X'
            &&
            document.getElementById(2.3).innerText=='X'
            ){
            alert("Player-2 wins")
    }
    else if(document.getElementById(3.1).innerText=='X'
            &&
            document.getElementById(3.2).innerText=='X'
            &&
            document.getElementById(3.3).innerText=='X'
            ){
            alert("Player-2 wins")
    }
    else if(document.getElementById(1.1).innerText=='X'
            &&
            document.getElementById(2.1).innerText=='X'
            &&
            document.getElementById(3.1).innerText=='X'
            ){
            alert("Player-2 wins")
    }
    else if(document.getElementById(1.2).innerText=='X'
            &&
            document.getElementById(2.2).innerText=='X'
            &&
            document.getElementById(3.2).innerText=='X'
            ){
            alert("Player-2 wins")
    }
    else if(document.getElementById(1.3).innerText=='X'
            &&
            document.getElementById(2.3).innerText=='X'
            &&
            document.getElementById(3.3).innerText=='X'
            ){
            alert("Player-2 wins")
    }
    else if(document.getElementById(1.1).innerText=='X'
            &&
            document.getElementById(2.2).innerText=='X'
            &&
            document.getElementById(3.3).innerText=='X'
            ){
            alert("Player-2 wins")
    }
    else if(document.getElementById(1.3).innerText=='X'
            &&
            document.getElementById(2.2).innerText=='X'
            &&
            document.getElementById(3.1).innerText=='X'
            ){
            alert("Player-2 wins")
    }
}